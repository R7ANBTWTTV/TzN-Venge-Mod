//Author : Igloo?
//Features : Lighting Fix
pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    if (pc.currentMap == "Sierra") {
      pc.app.renderer.scene.skyboxIntensity = 1.5
      pc.app.root.findByName("Light").light.color = {
        r: 0,
        g: 0,
        b: 0,
        a: 1,
      };
    }
if (pc.currentMap == "Mistle") {
      pc.app.renderer.scene.skyboxIntensity = 0
      pc.app.root.findByName("Light").light.color = {
        r: 0,
        g: 0,
        b: 0,
        a: 1,
      };
    }
    if (pc.currentMap == "Xibalba") {
    pc.app.renderer.scene.skyboxIntensity = 0
      pc.app.root.findByName("Light").light.color = {
        r: 0,
        g: 0,
        b: 0,
        a: 1,
      };
    }
    if (pc.currentMap == "Tundra") {
    pc.app.renderer.scene.skyboxIntensity = 0
      pc.app.root.findByName("Light").light.color = {
        r: 0,
        g: 0,
        b: 0,
        a: 1,
      };
    }
  }, 2000);
});
