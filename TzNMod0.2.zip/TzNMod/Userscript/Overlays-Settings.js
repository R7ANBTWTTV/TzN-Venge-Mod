//-This Script is Officially created by "Igloo" (AKA : ChetanIsNoob) 
//-below down there are 3 Theme which u can choose accordingly with ur preference of what color u like 
//-My Personal Best theme is Green. So i Already gave "GreenTheme = 1". Giving this value of 1 make GreenTheme 
//-enable
// You can Also choose any color theme u want but make sure u give "1" value to one theme only , to avoid colors 
// mixing 
// One more thing i would recommend to use Hell mod for redTheme better experience
//And FOV mod for GreenTheme for better experience

RedTheme = 0;
GreenTheme = 0;
PurpleTheme = 1;
